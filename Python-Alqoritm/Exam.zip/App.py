import random


# Task1
def word_count(text, word_for_search):
    text = text.lower()
    count = 0
    for i in text.split():
        if not i.isalpha():
            for j in i:
                if not j.isalpha():
                    i = i.replace(j, "")
        if i == word_for_search.lower() or i[::-1] == word_for_search.lower():
            count += 1
    return count


text_input = '''Мне было 22 года, когда я попросил своего отца дать мне шанс попробовать себя в деле, которое мне нравится. Работать у своего отца, который директор компании — самый легкий способ, но он меня не устраивал и не удовлетворял моих амбиций.
Я только добавил при этом, что, если у меня что-то не получится, я вернусь, и признаюсь, что я дурак. Но в глубине души я знал, что не смогу прийти к отцу с опущенной головой и признать свое поражение, — какой я после этого мужчина?'''

word_input = "я"

print("Слово  '" + word_input + "' встречается в тексте " + str(word_count(text_input, "я")) + " раз")
print()




# Task2
word_list = []
list_size = int(input("Введите количество слов для поиска: "))
for i in range(list_size):
    word_list.append(input("Введите слово " + str(i+1) + "/" + str(list_size) + ": "))
for i in word_list:
    print("Слово  '" + i + "' встречается в тексте " + str(word_count(text_input, i)) + " раз")
print()



#Task3
text = "Мама купила две пачки соли. Мама использовала одну пачку соли для обеда."
search_list = ["мама", "купила", "использовала", "для", "обеда"]
replase_list = ["папа", "купил", "съел", "за", "обедом"]
statistic = ""
print("Исходный текст: ".center(50))
print(text)
for i in search_list:
    statistic += i + "/" + replase_list[search_list.index(i)] + " - " + str(word_count(text, i)) + ", "
    text = text.replace(i.title(), replase_list[search_list.index(i)].title())
    text = text.replace(i.lower(), replase_list[search_list.index(i)].lower())
    text = text.replace(i.upper(), replase_list[search_list.index(i)].upper())
print("Текст после замены: ".center(50))
print(text)
print("Статистика: ".center(50))
print(statistic.rstrip(", "))
print()



#Task4
lst1 = []
lst2 = []
lst3 = []
lst4 = []
lst5 = []
for i in range(5):
    lst1.append(random.randint(1, 100))
    lst2.append(random.randint(1, 100))
    lst3.append(random.randint(1, 100))
    lst4.append(random.randint(1, 100))

# 4_1

lst5 = lst1 + lst2 + lst3 + lst4
lst5.sort()
lst5.reverse()
print("1) " + str(lst5))
lst5.clear()
print()

# 4_2

lst1_u = []
for i in lst1:
    if i not in lst1_u and lst1.count(i) == 1:
        lst1_u.append(i)
lst2_u = []
for i in lst2:
    if i not in lst2_u and lst2.count(i) == 1:
        lst2_u.append(i)
lst3_u = []
for i in lst3:
    if i not in lst3_u and lst3.count(i) == 1:
        lst3_u.append(i)
lst4_u = []
for i in lst4:
    if i not in lst4_u and lst4.count(i) == 1:
        lst4_u.append(i)
lst5 = lst1_u + lst2_u + lst3_u + lst4_u
print("2) " + str(lst5))
print()
lst5.clear()
# 4_3

ls1 = lst1.copy()
ls2 = lst2.copy()
ls3 = lst3.copy()
ls4 = lst4.copy()

for i in ls1:
    if i in ls2 and i in ls3 and i in ls4:
        lst5.append(i)
        ls1.remove(i)
        ls2.remove(i)
        ls3.remove(i)
        ls4.remove(i)

print("3) " + str(lst5))
lst5.clear()
print()
# 4_4

for i in lst1 + lst2 + lst3 + lst4:
    k = 0
    for j in range(2, i):
        if (i % j) == 0:
            k += 1
    if k <= 0:
        lst5.append(i)

ls5 = lst5.copy()

for i in lst5:
    if lst5.count(i) > 1:
        ls5.remove(i)
print("4) " + str(ls5))
print()




#Task5
mystr = "2+3-7"

mystr = mystr.replace(" ", "")
operand1 = 0
operand2 = 0
operator = ""
result = 0

if len(mystr) % 2 != 0 and mystr[0].isdigit() and mystr[len(mystr) - 1].isdigit():
    for i in range(0, len(mystr), 2):
        if mystr[i].isdigit():
            check1 = "ok"
        else:
            check1 = "fail"
            break
    for i in range(1, len(mystr), 2):
        if mystr[i] == "+" or mystr[i] == "-":
            check2 = "ok"
        else:
            check2 = "fail"
            break

    if check1 == "ok" and check2 == "ok":
        for i in range(0, len(mystr), 2):
            if i <= len(mystr) - 2:
                operator = mystr[i + 1]
                if i == 0:
                    operand1 = int(mystr[i])
                else:
                    operand1 = result
                operand2 = int(mystr[i + 2])
                if operator == "+":
                    result = operand1 + operand2
                else:
                    result = operand1 - operand2
        print(result)
    elif check1 == "fail":
        print("Неверный ввод числа! ")
    elif check2 == "fail":
        print("Неверный ввод оператора! Допускается только (+ и -)")
    else:
        print("Ошибка ввода!")
else:
    print("Ошибка ввода!")